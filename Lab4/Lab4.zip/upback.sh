#1/bin/bash

if [[ !(-d ~/restore) ]]; then
    mkdir ~/restore
fi

cur_dir="$HOME"
max_time=0

for cur in $(ls -d "$HOME/Backup-"????"-"??"-"?? 2> /dev/null); do
    if [[ -d $cur ]]; then
        cur_date=$(echo "$cur" | grep -o "[[:digit:]]\{4\}-[[:digit:]]\{2\}-[[:digit:]]\{2\}")
        
        if [[ -z "$cur_date" ]]; then
            continue
        fi
        
        cur_seconds=$(date +"%s" -d "$cur_date" 2> /dev/null)
        
        if [[ $? != 0 ]]; then
            continue
        fi
        
        if (( "$cur_seconds" > "$max_time" )); then
            cur_dir=$cur
            max_time=$cur_seconds
            break
        fi
    fi
done

if [[ "$cur_dir" == "$HOME" ]]; then
    echo "There is no backups"
    exit 0
fi

for file in $(ls $cur_dir); do
    if [[ -f "$cur_dir/$file" ]]; then
        if [[ ! "$file" =~ .*\.[[:digit:]]{4}-[[:digit:]]{2}-[[:digit:]]{2}$ ]]; then
            cp "$cur_dir/$file" ~/restore
        fi
    fi
done

echo "Successfully upbacked"
